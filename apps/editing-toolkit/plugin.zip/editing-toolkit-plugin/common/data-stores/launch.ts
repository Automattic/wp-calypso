/**
 * External dependencies
 */
import { Launch } from '@automattic/data-stores';

Launch.register();
