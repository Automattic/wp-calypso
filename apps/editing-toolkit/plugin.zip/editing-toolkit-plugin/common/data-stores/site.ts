/**
 * External dependencies
 */
import { Site } from '@automattic/data-stores';

Site.register( { client_id: '', client_secret: '' } );
