/**
 * External dependencies
 */
import { DomainSuggestions } from '@automattic/data-stores';

DomainSuggestions.register( { vendor: 'variation2_front' } );
