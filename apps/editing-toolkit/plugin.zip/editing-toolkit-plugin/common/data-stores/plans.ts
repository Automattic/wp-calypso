/**
 * External dependencies
 */
import { Plans } from '@automattic/data-stores';

Plans.register();
