/**
 * Internal dependencies
 */
import './index.scss';
