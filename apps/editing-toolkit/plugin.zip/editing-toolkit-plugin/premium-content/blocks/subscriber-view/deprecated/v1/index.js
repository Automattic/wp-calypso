export default [
	{
		attributes: {},
		supports: {
			inserter: false,
			html: false,
		},
		save: () => <div className="wp-block-premium-content-subscriber-view"></div>,
	},
];
