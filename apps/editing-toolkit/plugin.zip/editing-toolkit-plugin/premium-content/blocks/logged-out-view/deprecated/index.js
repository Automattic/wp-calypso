/**
 * Internal Dependencies
 */
import deprecatedV1 from './v1';
import deprecatedV2 from './v2';

export default [ deprecatedV1, deprecatedV2 ];
