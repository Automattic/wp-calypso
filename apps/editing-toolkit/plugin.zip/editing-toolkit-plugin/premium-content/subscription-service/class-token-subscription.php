<?php declare( strict_types = 1 );

namespace A8C\FSE\Earn\PremiumContent\SubscriptionService;

class Token_Subscription {

	/**
	 * @var string
	 */
	public $end_date = '';
}
