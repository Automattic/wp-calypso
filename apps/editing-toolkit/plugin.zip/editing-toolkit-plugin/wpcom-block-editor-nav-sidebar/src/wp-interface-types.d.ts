declare module '@wordpress/interface' {
	export const __experimentalMainDashboardButton: React.ComponentType;
}
