declare module '@wordpress/components' {
	const Tip: React.ComponentType< any >;
}

export {};
