/**
 * Internal dependencies
 */
import './synced-newspack-blocks/blocks/carousel/view';
