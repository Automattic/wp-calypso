/**
 * Internal dependencies
 */
import './blocks/src/index';
