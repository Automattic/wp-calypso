/**
 * Internal dependencies
 */
import './block-inserter';
import './template-validity-override';
import './image-block-keywords';
import './style.scss';
import './suppress-trash-action';
import './suppress-draft-action';
import './remove-editor-panels';
