/**
 * External dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

export default () => <InnerBlocks.Content />;
