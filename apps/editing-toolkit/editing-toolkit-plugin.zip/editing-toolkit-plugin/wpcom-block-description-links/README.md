# Block Description Links

## Summary

This adds a "Learn more" link inline with the Block Description **ONLY** when displayed in the block editor.

## Adding more

To extend this to more blocks you can add the block name along with the desired external link to the map found in [./src/block-links-map.ts](./src/block-links-map.ts). Please notice they are segregated as Core, Jetpack, and A8C.
