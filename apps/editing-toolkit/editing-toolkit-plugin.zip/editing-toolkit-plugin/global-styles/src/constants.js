export const FONT_BASE = 'font_base';
export const FONT_BASE_DEFAULT = 'font_base_default';
export const FONT_HEADINGS = 'font_headings';
export const FONT_HEADINGS_DEFAULT = 'font_headings_default';
export const FONT_PAIRINGS = 'font_pairings';
export const FONT_OPTIONS = 'font_options';
export const SITE_NAME = 'blogname';
