import { registerTimelineBlock } from './timeline';
import { registerTimelineItemBlock } from './timeline-item';

import './editor.scss';
import './style.scss';

registerTimelineBlock();
registerTimelineItemBlock();
