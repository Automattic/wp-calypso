import { register } from './src/store';

import './src/disable-core-nux';
import './src/block-editor-nux';

register();
