# Nux Welcome Tour Modal

A help tour to show new users some of the basics of using the editor.

## Testing Instructions

Instructions for testing the modal and its variants, and for resetting the state of `nux-status` so that the modal is shown again can be found on the PR [#47779](https://github.com/Automattic/wp-calypso/pull/47779)
