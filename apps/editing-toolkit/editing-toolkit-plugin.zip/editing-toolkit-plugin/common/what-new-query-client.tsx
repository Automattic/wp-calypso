import { QueryClient } from 'react-query';

export const whatsNewQueryClient = new QueryClient();
