import './hide-plugin-buttons-mobile.scss';
