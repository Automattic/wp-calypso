import { Launch } from '@automattic/data-stores';

export type LaunchStepType = Launch.LaunchStepType;

Launch.register();
