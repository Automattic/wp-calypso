import { WPCOMFeatures } from '@automattic/data-stores';

WPCOMFeatures.register();
