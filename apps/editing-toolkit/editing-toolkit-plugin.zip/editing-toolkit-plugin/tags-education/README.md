# Tags Education

## Add Tags Education Link

- [add-tags-education-link](./src/add-tags-education-link.js) add tags education link to let blogger learn more about tags.
