import './src/add-tags-education-link';
