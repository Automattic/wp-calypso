# Block Inserter Modifications

## Contextual Tips

- [contextual-tips](./contextual-tips.js) add Tips to the searcher box when the term matches with some of the keywords defined by the component.
