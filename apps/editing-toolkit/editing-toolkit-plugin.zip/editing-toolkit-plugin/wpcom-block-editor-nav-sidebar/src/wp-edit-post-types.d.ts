declare module '@wordpress/edit-post' {
	export const __experimentalMainDashboardButton: React.ComponentType;
}
