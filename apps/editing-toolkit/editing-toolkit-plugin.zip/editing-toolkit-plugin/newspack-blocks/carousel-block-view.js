import './synced-newspack-blocks/blocks/carousel/view';
