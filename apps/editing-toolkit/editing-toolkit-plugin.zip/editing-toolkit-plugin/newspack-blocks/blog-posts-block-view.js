import './synced-newspack-blocks/blocks/homepage-articles/view';
