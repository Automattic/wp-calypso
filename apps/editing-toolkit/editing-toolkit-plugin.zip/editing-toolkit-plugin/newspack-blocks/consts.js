/**
 * Block name in the A8C\FSE context.
 */
export const CAROUSEL_BLOCK_NAME = 'a8c/posts-carousel';
