export const FLOW_ID = 'gutenboarding';
export const GUTENBOARDING_LAUNCH_FLOW = 'gutenboarding-launch';
export const FOCUSED_LAUNCH_FLOW = 'focused-launch';
export const SITE_LAUNCH_FLOW = 'launch-site';
export const IMMEDIATE_LAUNCH_QUERY_ARG = 'should_launch';
